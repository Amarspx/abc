$(document).ready(function($){

$('.menu-icon').click(function(){
	$('.main-menu ').slideToggle();
});

});